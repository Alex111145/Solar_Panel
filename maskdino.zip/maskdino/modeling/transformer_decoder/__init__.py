# Copyright (c) IDEA, Inc. and its affiliates.
from .maskdino_decoder import MaskDINODecoder

